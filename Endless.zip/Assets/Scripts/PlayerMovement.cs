﻿using System.Collections;
using System.Collections.Generic;

using UnityEngine;
using UnityEngine.AI;

public class PlayerMovement : MonoBehaviour
{
    // Start is called before the first frame update
    public float speed = 1f;
    NavMeshAgent m_agent;
    public GameObject target;
    Vector3 pos;
    void Start()
    {
        m_agent = GetComponent<NavMeshAgent>();
        target = GameObject.Find("target");
    }

    // Update is called once per frame
    void Update()
    {
        pos = target.transform.position;
        m_agent.destination = pos;
        pos.z += 0.02f;
        target.transform.position = pos;

        if (Input.GetKey(KeyCode.Space))
            GetComponent<Rigidbody>().AddForce(Vector3.up * 10, ForceMode.Impulse);

    }

   public void OnTriggerEnter(Collider other)
    {
        //if(other.tag.Equals("Coin"))
        //    other.transform.position = UnityEngine.Vector3.Lerp(other.transform.position, transform.position, 0.00002f * Time.deltaTime);
    }
}
