﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformTile : MonoBehaviour
{
    public Transform startPoint;
    public Transform endPoint;
    public GameObject[] obstacles; //Objects that contains different obstacle types which will be randomly activated
    public TilesSpawner groundGenerator;

    private void Start()
    {
        groundGenerator = GameObject.FindObjectOfType<TilesSpawner>();
    }

    public void ActivateRandomObstacle()
    {
        DeactivateAllObstacles();

        System.Random random = new System.Random();
        int randomNumber = random.Next(0, obstacles.Length);
        obstacles[randomNumber].SetActive(true);
    }

    public void DeactivateAllObstacles()
    {
        for (int i = 0; i < obstacles.Length; i++)
        {
            obstacles[i].SetActive(false);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        groundGenerator.SpawnCoins(this.gameObject);
        ActivateRandomObstacle();
    }

    private void OnTriggerExit(Collider other)
    {
        
        groundGenerator.SpawnTiles(this.gameObject);
       
        Destroy(gameObject, 30);
    }
}
