﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public class ButtonTest : MonoBehaviour
{
    int timeRemaining = 30;
    public void CoinMultiplier()
    {
        StartCoroutine(MultiplyCoins());
        
    }
   
    IEnumerator MultiplyCoins()
    {
               
        Button buttonRef = GetComponent<Button>();
        buttonRef.interactable = false;          
        TilesSpawner tilesSpawner = GameObject.FindObjectOfType<TilesSpawner>();
        tilesSpawner.coinCount = 6;
        yield return new WaitForSeconds(15f);
        buttonRef.interactable = true;
        tilesSpawner.coinCount = 2;
    }

    public void Magnet()
    {
        Coins[] m_coins = GameObject.FindObjectsOfType<Coins>();
        GameObject player = GameObject.FindGameObjectWithTag ("Player");
        player.transform.GetChild(1).gameObject.SetActive(true);
        foreach (Coins coin in m_coins)
        {
            coin.transform.position = Vector3.Lerp(transform.position, player.transform.position, 0.00002f * Time.deltaTime);
        }
    }
}
