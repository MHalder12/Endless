﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class TilesSpawner : MonoBehaviour
{
    public GameObject tilePrefab;
    public NavMeshSurface navMesh;
    public GameObject coinprefab;
   public void SpawnTiles(GameObject tile)
    {
        GameObject spawnedTile = Instantiate(tile, tile.transform.GetChild(0).position, Quaternion.identity);
        navMesh.BuildNavMesh();
        //tile.GetComponent<PlatformTile>().ActivateRandomObstacle();
    }
    public int coinCount =4;
    public void SpawnCoins(GameObject tileref)
    {
        //coinCount = 4;
        for (int i=0;i< coinCount; i++)
        {
            GameObject temp = Instantiate(coinprefab, transform);
            temp.transform.position = GetRandomPointInCollider(tileref.GetComponent<Collider>());
        }
    }

    Vector3 GetRandomPointInCollider(Collider collider)
    {
        Vector3 point = new Vector3(
            Random.Range(collider.bounds.min.x, collider.bounds.max.x),
            Random.Range(collider.bounds.min.y, collider.bounds.max.y),
            Random.Range(collider.bounds.min.z, collider.bounds.max.z));
        if(point!= collider.ClosestPoint(point))
        {
            point = GetRandomPointInCollider(collider);
        }
        point.y = 1;
        return point;
    }
}
